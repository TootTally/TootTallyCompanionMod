﻿using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;

namespace TootTally
{

    [BepInPlugin("TootTallyTest", "Toot Tally (Test)", "0.0.1")]
    public class Plugin : BaseUnityPlugin
    {
        public static new ManualLogSource Logger;
        public ConfigEntry<string> APIKey { get; private set; }
        public ConfigEntry<bool> AllowTMBUploads { get; private set; }

        private void Awake()
        {
            Logger = base.Logger;
            // Config
            APIKey = Config.Bind("API Setup", "API Key", "SignUpOnTootTally.com", "API Key for Score Submissions");
            AllowTMBUploads = Config.Bind("API Setup", "Allow Unknown Song Uploads", false, "Should this mod send unregistered charts to the TootTally server?");
            // TODO: Fix TrombSettings optionality
            //if (OptionalTrombSettings.enabled) {
            object? settings = OptionalTrombSettings.GetConfigPage("TootTally");
            if (settings != null)
            {
                OptionalTrombSettings.Add(settings, AllowTMBUploads);
                OptionalTrombSettings.Add(settings, APIKey);
            }
               
           // }
            // The rest of the code follows
        }
    }
}